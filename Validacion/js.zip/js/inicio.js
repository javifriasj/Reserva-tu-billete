$(document).ready(function() {
    var ready = null;
    
    ready = new elements();

    var money = $('<label class="tres">Precio (Máx)</label><input type="number" value="750" id="money"><label>€</label><br>');
    var exit = $('<label class="cuatro">Hora Salida</label><input type="time" value="00:00" id="exit"><br>');
    var enter = $('<label class="cinco">Hora Llegada</label><input type="time" value="23:00" id="enter"><br>');
    var selector = $('<label class="seis">Aerolineas</label><select id="aerolineas"></select><br>');
    var send = $('<input  class="veintiocho" type="button" value="Buscar" id="send">');

    $("#busquedaizquierda").append(money);
    $("#busquedaizquierda").append(exit);
    $("#busquedaizquierda").append(enter);
    $("#busquedaizquierda").append(selector);
    $("#busquedaizquierda").append(send);
    
    lang = "ES1";

    var ES = document.querySelector(".ES");
    var EN = document.querySelector(".EN");
    var FR = document.querySelector(".FR");

    $(ES).on("click", function () {
        lang = "ES1";
        v();
    });
    $(EN).on("click", function () {
        lang = "EN1";
        v();
    });
    $(FR).on("click", function () {
        lang = "FR1";
        v();
    });
    
    function v()
    {
        conexionInit = new XMLHttpRequest();
        conexionInit.open("GET", "/Avion/Lang/" + lang + ".txt", false);
        conexionInit.send();

        pru = JSON.parse(conexionInit.responseText);

        $(".uno").text(pru.uno);
        $(".dos").text(pru.dos);
        $(".tres").text(pru.tres);
        $(".cuatro").text(pru.cuatro);
        $(".cinco").text(pru.cinco);
        $(".seis").text(pru.seis);
        $(".siete").text(pru.siete);
        $(".ocho").text(pru.ocho);
        $(".nueve").text(pru.nueve);
        $(".diez").text(pru.diez);
        $(".once").text(pru.once);
        $(".doce").text(pru.doce);
        $(".trece").text(pru.trece);
        $(".catorce").text(pru.catorce);
        $(".quince").text(pru.quince);
        $(".dieciseis").text(pru.dieciseis);
        $(".diecisiete").text(pru.diecisiete);
        $(".dieciocho").text(pru.dieciocho);
        $(".diecinueve").text(pru.diecinueve);
        $(".veinte").text(pru.veinte);
        $(".veintiuno").text(pru.veintiuno);
        $(".veintidos").text(pru.veintidos);
        $(".veintitres").text(pru.veintitres);
        $(".veinticuatro").text(pru.veinticuatro);
        $(".veinticinco").text(pru.veinticinco);
        $(".veintiseis").text(pru.veintiseis);
        $(".veintisiete").text(pru.veintisiete);
        $(".veintiocho").text(pru.veintiocho);
        $(".veintinueve").text(pru.veintinueve);
        $(".treinta").text(pru.treinta);
        $(".treintaiuno").text(pru.treintaiuno);
        $(".treintaidos").text(pru.treintaidos);
        $(".treintaitres").text(pru.treintaitres);
        $(".treintaicuatro").text(pru.treintaicuatro);
        $(".treintaicinco").text(pru.treintaicinco);
        $(".treintaiseis").text(pru.treintaiseis);
        $(".treintaisiete").val(pru.treintaisiete);
        
    }
    
    ready.conexion();
});