$(document).ready(function () {

    lang = "ES";

    var ES = document.querySelector(".ES");
    var EN = document.querySelector(".EN");
    var FR = document.querySelector(".FR");

    $(ES).on("click", function () {
        lang = "ES";
        v();
    });
    $(EN).on("click", function () {
        lang = "EN";
        v();
    });
    $(FR).on("click", function () {
        lang = "FR";
        v();
    });

    function v()
    {
        conexionInit = new XMLHttpRequest();
        conexionInit.open("GET", "Lang/" + lang + ".txt", false);
        conexionInit.send();

        lang = JSON.parse(conexionInit.responseText);

        $(".uno").text(lang.uno);
        $(".dos").text(lang.dos);
        $(".tres").text(lang.tres);
        $(".cuatro").text(lang.cuatro);
        $(".cinco").text(lang.cinco);
        $(".seis").text(lang.seis);
        $(".siete").text(lang.siete);
        $(".ocho").text(lang.ocho);
        $(".nueve").text(lang.nueve);
        $(".diez").text(lang.diez);
    }
});