elements = function()
{
	var conexion1;

	var content;
}

elements.prototype.conexion = function()
{
	conexion1 = new XMLHttpRequest();
  	conexion1.onreadystatechange = function(){ elements.prototype.firstconexion() };
  	conexion1.open('GET','pagina1.php', true);
  	conexion1.send();
}

elements.prototype.firstconexion = function()
{
	if(conexion1.readyState == 4)
	{             
		content=JSON.parse(conexion1.responseText);
	} 
}